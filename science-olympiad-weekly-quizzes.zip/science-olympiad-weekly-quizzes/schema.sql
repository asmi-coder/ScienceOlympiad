-- Execute in the Supabase SQL editor for this project's database.
create table if not exists public.quiz_attempts (
  id uuid primary key default gen_random_uuid(),
  student_name text not null check (char_length(student_name) between 2 and 80),
  quiz_id text not null check (quiz_id in ('heredity','thermodynamics','codebusters')),
  earned_points numeric(8,3) not null check (earned_points >= 0),
  max_points integer not null check (max_points > 0),
  question_results jsonb not null,
  submitted_answers jsonb not null,
  created_at timestamptz not null default now()
);

create index if not exists quiz_attempts_created_at_idx on public.quiz_attempts(created_at desc);
create index if not exists quiz_attempts_quiz_idx on public.quiz_attempts(quiz_id, created_at desc);

alter table public.quiz_attempts enable row level security;
-- There are intentionally NO anon/authenticated RLS policies for quiz_attempts.
-- Only trusted Netlify Functions using the service-role key can read/write.
revoke all on table public.quiz_attempts from anon, authenticated;
-- Netlify Functions validate admins using Supabase Auth and ADMIN_USER_ID.
