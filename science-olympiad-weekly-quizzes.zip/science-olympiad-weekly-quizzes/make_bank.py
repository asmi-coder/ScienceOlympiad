import json, random, string
from pathlib import Path
ROOT=Path(__file__).parent
Q={"heredity":[],"thermodynamics":[],"codebusters":[]}
meta={
"heredity":{"title":"Heredity","subtitle":"DNA expression · PCR · Population genetics","color":"mint","materials":"2027 Division B: up to two Class II calculators and one double-sided 8.5 × 11 in. notes sheet per team.","topics":["Transcription & translation","PCR & biotechnology","Population genetics"]},
"thermodynamics":{"title":"Thermodynamics","subtitle":"Zeroth law · First law · Second law","color":"amber","materials":"2027 Division B: up to two Class III calculators and permitted printed resources per team. This is written-test practice, not device testing.","topics":["Zeroth law & equilibrium","First law & energy","Second law & entropy"]},
"codebusters":{"title":"Codebusters","subtitle":"Aristocrats · Checkerboard · Homophonic","color":"purple","materials":"2027 Division B: writing utensils only; supervisor supplies relevant cipher reference tables. No calculator or personal reference sheet.","topics":["Aristocrat substitutions","5×5 checkerboard","Homophonic ciphers"]}}

def add(quiz,topic,kind,prompt,explanation,**kw):
 n=len(Q[quiz])+1; level='basic' if n<=5 else 'intermediate' if n<=10 else 'advanced'; pts={'basic':2,'intermediate':3,'advanced':5}[level]
 Q[quiz].append(dict(id=f'{quiz[:1]}{n:02d}',number=n,level=level,points=pts,topic=topic,kind=kind,prompt=prompt,explanation=explanation,**kw))

t=meta['heredity']['topics']
add('heredity',t[0],'choice',"A DNA template strand reads 3′–TAC GGA ACT–5′. What mRNA is transcribed (5′→3′)?","RNA polymerase reads the DNA template 3′→5′ and builds the complementary mRNA 5′→3′: TAC→AUG, GGA→CCU, ACT→UGA.",options=['5′–AUG CCU UGA–3′','5′–UAC GGA ACU–3′','3′–AUG CCU UGA–5′','5′–ATG CCT TGA–3′'],correct=0)
add('heredity',t[1],'choice',"In a standard PCR cycle, what is the main purpose of heating a sample to about 95°C?","High heat breaks hydrogen bonds between DNA strands (denaturation). Primers anneal at a lower temperature, and thermostable polymerase extends DNA at its optimal temperature.",options=['To separate the two DNA strands','To attach primers to the template','To synthesize the complementary DNA','To cut DNA at restriction sites'],correct=0)
add('heredity',t[2],'choice',"Which condition is required for the simple Hardy–Weinberg model to maintain constant allele frequencies?","Hardy–Weinberg assumes random mating, a very large population, and no mutation, migration, or selection. Strong migration would change allele frequencies.",options=['Random mating and no migration','A small population with frequent drift','Strong selection favoring one genotype','A high rate of new mutations'],correct=0)
add('heredity',t[0],'sequence',"The DNA coding strand is 5′–ATG CCT TAA–3′. Enter the mature mRNA sequence from this region in the 5′→3′ direction. Assume no introns.","The coding DNA strand matches mRNA except that U replaces T. Therefore ATG CCT TAA becomes 5′–AUG CCU UAA–3′.",answer='AUGCCUUAA',label='mRNA, 5′→3′ (letters only)')
add('heredity',t[1],'multi',"Select ALL components needed to amplify a double-stranded DNA target by ordinary PCR.","Ordinary PCR requires DNA template, a pair of primers, dNTPs, buffer/Mg²⁺, and a thermostable DNA polymerase. RNA ligase is not part of the standard amplification reaction.",options=['A thermostable DNA polymerase','Deoxyribonucleotide triphosphates (dNTPs)','Forward and reverse DNA primers','RNA ligase to join the primers'],correct=[0,1,2])
add('heredity',t[2],'number',"In a Hardy–Weinberg population, 9% show an autosomal recessive phenotype (aa). What percentage are heterozygous carriers (Aa)? Enter a percentage (not a decimal).","q²=0.09, so q=0.30 and p=0.70. Heterozygotes occur at 2pq=2(0.7)(0.3)=0.42, or 42%.",answer=42,tolerance=.05,unit='%')
add('heredity',t[0],'choice',"The DNA template strand is 3′–AAG TCC GTA–5′. The supplied codon information is UUC=Phe, AGG=Arg, CAU=His, AAG=Lys, UCC=Ser. Which peptide is produced if this region is translated in the shown reading frame?","The template produces 5′–UUC AGG CAU–3′. Ribosomes read those 5′→3′ codons, producing Phe–Arg–His.",options=['Phe–Arg–His','Lys–Ser–His','Phe–Ser–His','His–Arg–Phe'],correct=0)
add('heredity',t[1],'number',"A PCR reaction begins with one double-stranded DNA target. Assuming perfect doubling each cycle and ignoring plateau effects, how many double-stranded target copies exist after 7 cycles?","Ideal PCR doubles each cycle: 1×2⁷=128 double-stranded molecules. Real experiments may depart from perfect doubling.",answer=128,tolerance=0,unit='copies')
add('heredity',t[2],'choice',"A hurricane randomly kills most of an island's beetles. The survivors have very different allele frequencies even though no color is favored. Which process best explains the change?","A population bottleneck changes allele frequencies through chance sampling of survivors. Natural selection would require a consistent fitness difference related to the allele.",options=['Genetic drift via a bottleneck','Directional natural selection','Nonrandom mating alone','An increase in DNA replication accuracy'],correct=0)
add('heredity',t[0],'choice',"A coding DNA sequence is 5′–ATG AAA GGC TAA–3′. The first A in the second codon is deleted. What is the best prediction for translation from the original start codon?","Deleting one nucleotide changes the reading frame downstream of that position. The new codons begin ATG AAG GCT ... rather than ATG AAA GGC ..., and later stop placement may change.",options=['A frameshift changes downstream codons','Only the second amino acid can change','Every later codon remains the same','The original reading frame is preserved'],correct=0)
add('heredity',t[1],'fields',"A double-stranded PCR target has the top strand 5′–AGTC TTAACG CGAT–3′ (spaces added for readability). Design 4-base primers that flank this whole displayed region. Enter EACH primer 5′→3′.","The forward primer equals the top strand's first four bases: AGTC. The reverse primer is the reverse complement of the top strand's last four bases, CGAT → ATCG (written 5′→3′).",fields=[{'label':'Forward primer, 5′→3′','answer':'AGTC','mode':'sequence'},{'label':'Reverse primer, 5′→3′','answer':'ATCG','mode':'sequence'}])
add('heredity',t[2],'fields',"In a large Hardy–Weinberg population, the aa phenotype is initially 16%. Migration changes the recessive allele frequency to q=0.25. Calculate (a) the INITIAL recessive allele frequency and (b) the NEW percentage of heterozygotes.","Initially q²=0.16, so q=0.40. After migration p=1−0.25=0.75; new 2pq=2(0.75)(0.25)=0.375=37.5%. These are two different time points.",fields=[{'label':'Initial q (decimal)','answer':.4,'mode':'number','tolerance':.001},{'label':'New heterozygotes (%)','answer':37.5,'mode':'number','tolerance':.05}])
add('heredity',t[0],'sequence',"A pre-mRNA contains EXON 1: 5′–AUG–3′, INTRON: 5′–CCAAUGG–3′, EXON 2: 5′–GAAUAA–3′. Assume ordinary splicing removes the entire intron and the exons are joined directly. Enter the mature coding-region mRNA sequence, 5′→3′.","RNA splicing removes the intron, not the exons. Joining AUG + GAAUAA produces 5′–AUGGAAUAA–3′, which encodes Met–Glu–Stop.",answer='AUGGAAUAA',label='Mature mRNA, letters only')
add('heredity',t[1],'number',"In quantitative PCR (qPCR), sample A reaches the threshold at cycle 18 and sample B at cycle 21. Assuming 100% amplification efficiency and equal thresholds, approximately how many times more starting target DNA did sample A contain than B?","A Ct difference of 3 cycles at 100% efficiency means 2³=8-fold more starting template in the earlier-threshold sample (A).",answer=8,tolerance=.05,unit='fold')
add('heredity',t[2],'number',"Before viability selection, a population has 400 AA, 400 Aa and 200 aa individuals. Survival to breeding is 100% for AA, 75% for Aa and 50% for aa. What is the recessive allele frequency q among the SURVIVORS? Give a decimal to 4 places.","Survivors: AA=400, Aa=300, aa=100 (800 total). Recessive alleles=300+2(100)=500; total alleles=2(800)=1600, so q=500/1600=0.3125. Do not assume Hardy–Weinberg after selection.",answer=.3125,tolerance=.00005,unit='decimal')

t=meta['thermodynamics']['topics']
add('thermodynamics',t[0],'choice',"Object A and object B are each separately in thermal equilibrium with a calibrated thermometer C. What does the Zeroth Law imply about A and B?","The Zeroth Law makes thermal equilibrium transitive. If A and C share a temperature and B and C share a temperature, then A and B share a temperature.",options=['They have the same temperature','They must have the same internal energy','They must have the same mass','They must transfer heat at the same rate'],correct=0)
add('thermodynamics',t[1],'number',"A gas absorbs 450 J of heat and does 150 J of work on the surroundings. Using ΔU=Q−W_by, find ΔU in joules.","Q=+450 J and W_by=+150 J, so ΔU=450−150=+300 J. Expansion work done BY the gas reduces its internal energy relative to the absorbed heat.",answer=300,tolerance=.01,unit='J')
add('thermodynamics',t[2],'choice',"A cyclic engine takes heat from a single thermal reservoir and claims to convert all of it into net work with no other effect. Which statement is correct?","The Kelvin–Planck statement of the Second Law forbids a cyclic engine from converting all heat extracted from one reservoir entirely into work without another effect.",options=['It violates the Second Law','It is possible if friction is zero','It violates only the Zeroth Law','It is possible at sufficiently high pressure'],correct=0)
add('thermodynamics',t[0],'number',"A sensor measures 27.0°C. Convert this temperature to kelvin using T(K)=T(°C)+273.15. Enter the numerical value.","27.0+273.15=300.15 K. A temperature difference of 1°C equals a difference of 1 K, but the zero points differ.",answer=300.15,tolerance=.01,unit='K')
add('thermodynamics',t[1],'choice',"An ideal gas is compressed adiabatically. The surroundings do 300 J of work ON the gas and there is no heat exchange. What is the internal energy change?","With ΔU=Q+W_on, Q=0 (adiabatic) and W_on=+300 J, so ΔU=+300 J. Work done ON the gas increases internal energy.",options=['+300 J','−300 J','0 J','+600 J'],correct=0)
add('thermodynamics',t[2],'number',"An ideal reversible heat engine operates between 600 K and 300 K reservoirs. Calculate the maximum Carnot efficiency as a percentage.","η_C=1−T_c/T_h=1−300/600=0.50=50%. Temperatures must be in kelvin.",answer=50,tolerance=.05,unit='%')
add('thermodynamics',t[0],'multi',"Select ALL intensive thermodynamic properties from this list (for a uniform equilibrium sample).","Temperature and pressure are intensive; their values do not scale with sample size. Mass and volume are extensive and add when combining samples.",options=['Temperature','Mass','Pressure','Volume'],correct=[0,2])
add('thermodynamics',t[1],'number',"A heat engine completes one cycle, absorbs 1200 J from a hot reservoir and rejects 850 J to a cold reservoir. What is its net work output per cycle?","For a full cycle ΔU=0. Therefore W_net=Q_in−Q_out=1200−850=350 J.",answer=350,tolerance=.01,unit='J')
add('thermodynamics',t[2],'number',"An amount of 600 J of heat flows directly from a 400 K reservoir to a 300 K reservoir. Assume their temperatures stay constant. Find the total entropy change of the two reservoirs in J/K.","The hot reservoir loses 600 J: ΔS_hot=−600/400=−1.5 J/K. The cold gains 600 J: ΔS_cold=+600/300=+2.0 J/K. Total ΔS=+0.5 J/K.",answer=.5,tolerance=.01,unit='J/K')
add('thermodynamics',t[0],'choice',"Two insulated copper blocks are initially at exactly 40°C, but block A has twice the mass of block B. They are put in good thermal contact. What occurs after they equilibrate?","They already have equal temperatures, so no net heat transfer occurs solely because the blocks have different masses. A does have more thermal energy relative to an equal reference temperature, but temperature sets heat-flow direction.",options=['No net heat flows between the blocks','Net heat flows from A to B because A is heavier','Net heat flows from B to A because B is lighter','Both blocks must settle at 20°C'],correct=0)
add('thermodynamics',t[1],'number',"In an insulated container, 0.20 kg of water at 80°C is mixed with 0.30 kg of water at 20°C. Assume no heat loss or phase change and equal specific heat for both samples. What is the final equilibrium temperature in °C?","Conservation of energy: 0.20(80−T)=0.30(T−20). Thus 16−0.2T=0.3T−6, so 22=0.5T and T=44°C.",answer=44,tolerance=.05,unit='°C')
add('thermodynamics',t[2],'fields',"A heat engine takes 2000 J from an 800 K reservoir, produces 900 J of work, and rejects the remaining heat to a 300 K reservoir per cycle. Find (a) rejected heat and (b) total entropy change of the reservoirs. Round entropy to 3 decimals.","Energy conservation gives Q_c=2000−900=1100 J. Total reservoir entropy is −2000/800+1100/300=−2.5+3.6667≈+1.167 J/K. Positive entropy production is consistent with the Second Law.",fields=[{'label':'Heat rejected (J)','answer':1100,'mode':'number','tolerance':.1},{'label':'Net reservoir entropy (J/K)','answer':1.167,'mode':'number','tolerance':.001}])
add('thermodynamics',t[0],'fields',"A resistance thermometer is calibrated as R(Ω)=100+0.40T(°C). It reads 120 Ω for block A and the same 120 Ω for block B, but 128 Ω for block C. Find (a) A's temperature and (b) C's temperature in °C. Which way would heat flow when B touches C?","Solve T=(R−100)/0.40. A and B are at 50°C; C is at 70°C. Heat flows spontaneously from C to B until equilibrium. The Zeroth Law says A and B are already mutually in equilibrium.",fields=[{'label':'Block A temperature (°C)','answer':50,'mode':'number','tolerance':.05},{'label':'Block C temperature (°C)','answer':70,'mode':'number','tolerance':.05},{'label':'Heat flows from (letter)','answer':'C','mode':'text'}])
add('thermodynamics',t[1],'fields',"At constant external pressure 100 kPa, a gas expands from 0.0020 m³ to 0.0050 m³ while absorbing 900 J of heat. Find (a) work done BY the gas and (b) ΔU. Use SI units.","W_by=PΔV=(100000 Pa)(0.0030 m³)=300 J. First Law: ΔU=Q−W_by=900−300=600 J. One Pa·m³ equals one joule.",fields=[{'label':'Work done by the gas (J)','answer':300,'mode':'number','tolerance':.1},{'label':'Change in internal energy (J)','answer':600,'mode':'number','tolerance':.1}])
add('thermodynamics',t[2],'fields',"A proposed cyclic engine absorbs 1000 J from a 500 K source and claims to output 450 J of work while rejecting the rest to a 300 K sink. Calculate (a) total entropy change of the reservoirs (J/K, 3 decimals) and (b) whether the engine is physically possible as described. Enter POSSIBLE or IMPOSSIBLE.","Q_c=1000−450=550 J. Reservoir entropy: −1000/500+550/300=−2+1.8333≈−0.167 J/K. Since total entropy decreases, the device violates the Second Law; Carnot efficiency is only 40%, less than the claimed 45%.",fields=[{'label':'Reservoir entropy change (J/K)','answer':-.167,'mode':'number','tolerance':.001},{'label':'POSSIBLE or IMPOSSIBLE','answer':'IMPOSSIBLE','mode':'text'}])

# --- Cipher functions; everything encrypted is generated from its keyed plaintext.
AZ='ABCDEFGHIJKLMNOPQRSTUVWXYZ'; AZ25=AZ.replace('J','')

def upper(s): return ''.join(c for c in s.upper() if c in AZ)

def make_derangement(seed):
 rng=random.Random(seed); target=list(AZ)
 while True:
  rng.shuffle(target)
  if all(a!=b for a,b in zip(AZ,target)): return dict(zip(AZ,target))

def encrypt_sub(text,seed):
 key=make_derangement(seed); return ''.join(key.get(ch,ch) for ch in text.upper()),key

def square(key):
 out=[]
 for a in upper(key)+AZ25:
  if a=='J': a='I'
  if a not in out: out.append(a)
 return [out[i*5:(i+1)*5] for i in range(5)]

def checkerboard(plaintext, key, rows, cols):
 grid=square(key); d={c:rows[i]+cols[j] for i,row in enumerate(grid) for j,c in enumerate(row)}
 ciphertext=' / '.join(' '.join(d['I' if c=='J' else c] for c in upper(w)) for w in plaintext.upper().split())
 used=set(ciphertext.replace(' / ','').replace(' ',''))
 if not set(rows+cols).issubset(used): print('NOTE header not all present',plaintext, ''.join(sorted(set(rows+cols)-used)))
 return ciphertext,grid

def homophone(plaintext,keyword,seed):
 # Authentic four-band arrangement: index 1-25, 26-50, 51-75, 76-100, with 00 for 100.
 assert len(keyword)==4 and len(set(keyword))==4 and all(c in AZ25 for c in keyword)
 enc={c:[] for c in AZ25}
 for block,k in enumerate(keyword):
  pivot=AZ25.index(k)
  for offset in range(25):
   letter=AZ25[(pivot+offset)%25]
   n=block*25+offset+1
   enc[letter].append(f'{n%100:02d}')
 rng=random.Random(seed)
 words=[]; index=0
 for w in plaintext.split():
  toks=[]
  for c in upper(w):
   if c=='J':c='I'
   toks.append(enc[c][rng.randrange(4)])
  words.append(' '.join(toks))
 return ' / '.join(words),enc

# The codebusters ciphertext includes word separators to allow text entry and self-marking.
t=meta['codebusters']['topics']
code_scenarios=[
(0,'PRACTICE MAKES PATTERNS CLEAR', 'Aristocrat — full substitution key supplied', 101),
(1,'PACK MY BOX WITH FIVE DOZEN LIQUOR JUGS', 'Checkerboard — keyed square supplied','CIPHER','GREAT','WORDS'),
(2,'SOLVE THE CODE ONE STEP AT A TIME', 'Homophonic — four-letter keyword supplied','LAMP',301),
(0,'EVERY LETTER HAS A PLACE IN THE PUZZLE', 'Aristocrat — substitution key supplied', 104),
(1,'QUICK VEXED WIZARDS PACK MY BOX WITH JUGS', 'Checkerboard — keyed square supplied','ORBIT','GREAT','WORDS'),
(2,'THE BEST CLUE OFTEN HIDES IN PLAIN SIGHT', 'Homophonic — keyword supplied','MINT',306),
(0,'A SHORT WORD CAN REVEAL A VERY LONG SECRET MESSAGE', 'Aristocrat — partial letter mappings supplied',107),
(1,'PACK FIVE BOXES WITH QUICK JUMPS AND ZERO WASTE', 'Checkerboard — build the keyed square','SCIENCE','GREAT','WORDS'),
(2,'LOOK FOR PATTERNS BEFORE YOU GUESS THE MESSAGE', 'Homophonic — three keyword letters supplied','BAND',309),
(0,'THE MOST USEFUL CLUE MAY BE A REPEATED THREE LETTER WORD', 'Aristocrat — partial letter mappings supplied',110),
(1,'BRAVE WIZARDS QUICKLY MIX JUGS OF FROZEN PAINT', 'Checkerboard — build the keyed square','THERMAL','GREAT','WORDS'),
(2,'FREQUENCY COUNTS CAN MISLEAD WHEN LETTERS HAVE MANY SYMBOLS', 'Homophonic — three keyword letters supplied','RISK',312),
(0,'WHEN EVERY SYMBOL SEEMS RANDOM SEARCH FOR WORD BOUNDARIES AND REPEATED ENDINGS BEFORE MAKING A GUESS', 'Aristocrat — no key supplied',113),
(1,'FIVE QUICK BOXERS JUMP WHILE ZANY WIZARDS STUDY CIPHER GRIDS', 'Checkerboard — build the keyed square','OLYMPIAD','GREAT','WORDS'),
(2,'THE FINAL MESSAGE REVEALS THAT PATIENCE AND CAREFUL RECORD KEEPING WIN THE CIPHER RACE', 'Homophonic — three keyword letters supplied','GLOW',315),
]
for i,(typ,plain,desc,*args) in enumerate(code_scenarios,1):
 if typ==0:
  cipher,key=encrypt_sub(plain,args[0]);
  if i<=5: note='Provided full alphabet (plaintext→ciphertext): '+AZ+' → '+''.join(key[a] for a in AZ)+'. Read the mapping in reverse to decrypt.'
  elif i<=10:
   # show useful plaintext mappings for 3 frequently occurring letters; cryptanalysis with a crib
   clues=['E','T','A','H']; note='Known plaintext→ciphertext pairs: '+', '.join(f'{a}→{key[a]}' for a in clues)+'. Other mappings must be inferred from word patterns.'
  else: note='No substitution alphabet is supplied. Spaces are preserved; no plaintext letter encrypts to itself.'
  extra={'ciphertext':cipher,'resource':note,'workbench':'letters'}
  expl=f"The decoded message is “{plain}.” Substitution is one-to-one throughout the question, so repeated cipher letters always stand for repeated plaintext letters. Use word lengths, frequency, and confirmed mappings to complete the alphabet."
 elif typ==1:
  key,rows,cols=args; cipher,grid=checkerboard(plain,key,rows,cols)
  squaretxt=' / '.join(' '.join(row) for row in grid)
  if i<=5: note=f'Polybius key: {key}. Row-key letters: {rows}. Column-key letters: {cols}. The 5×5 grid (rows top to bottom): {squaretxt}. Read each pair as row letter then column letter.'
  else: note=f'Polybius key: {key}. Row-key letters: {rows}. Column-key letters: {cols}. Build the 5×5 grid by writing the unique letters of the Polybius key first (I/J share one cell), then the unused alphabet letters; fill rows left→right. Each ciphertext pair is (row-key letter, column-key letter).'
  extra={'ciphertext':cipher,'resource':note,'workbench':'pairs'}
  expl=f"The original message is “{plain}.” Construct the 5×5 keyed Polybius square; each pair identifies one row and one column using the separate row and column keys. I/J use the same square cell."
 else:
  keyword,seed=args; cipher,enc=homophone(plain,keyword,seed)
  # At regional level the crib gives at least 3 letters of four-letter keyword. Reveal complete for basic, just 3 for mid and hard.
  if i<=6: hint=keyword
  else: hint=keyword[:3]+'?'
  note=f'Four-band homophonic cipher; known keyword letters (in order): {hint}. Each 25-number band (01–25, 26–50, 51–75, 76–00) maps its FIRST number to the corresponding keyword letter, then continues alphabetically through ABCDEFGHIKLMNOPQRSTUVWXYZ, wrapping around. The token 00 denotes 100. Each plaintext letter can use any of its four band numbers. Spaces/slashes separate words.'
  extra={'ciphertext':cipher,'resource':note,'workbench':'tokens'}
  expl=f"The four-letter keyword is {keyword}; the recovered plaintext is “{plain}.” Each number belongs to one of four 25-number bands. Start each band at its keyword letter and advance through the 25-letter I/J-combined alphabet, wrapping around. Subtract the band start to obtain the alphabet offset; keep the same offset from the band's keyword letter."
 if typ==0: topic=t[0]
 elif typ==1: topic=t[1]
 else: topic=t[2]
 kind='cipher'
 prompt=f"Decrypt the following {desc.split(' —')[0].lower()} message. Enter the entire plaintext sentence. Punctuation and spaces will not affect grading."
 add('codebusters',topic,kind,prompt,expl,answer=plain,**extra)

# exported bank
bank={'version':'2026-week1-v1','quizzes':{k:{**v,'questions':Q[k]} for k,v in meta.items()}}
(ROOT/'netlify/functions/_lib/bank.mjs').write_text('// Private server-side question bank. Do not copy into /public.\nexport const BANK = '+json.dumps(bank,ensure_ascii=False,indent=2)+';\n')
(ROOT/'tests/bank-snapshot.json').write_text(json.dumps({'counts':{k:len(v) for k,v in Q.items()},'code_sample':Q['codebusters'][0]['ciphertext']},indent=2))
print('Bank generated:',{k:len(v) for k,v in Q.items()})
