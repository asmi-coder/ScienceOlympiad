import test from 'node:test';
import assert from 'node:assert/strict';
import {BANK} from '../netlify/functions/_lib/bank.mjs';
import {publicQuiz,getQuiz,scoreQuestion,grade,normalizeLetters,demoAttempts} from '../netlify/functions/_lib/core.mjs';
import quizAPI from '../netlify/functions/quiz.mjs';
import submitAPI from '../netlify/functions/submit.mjs';
import authAPI from '../netlify/functions/auth.mjs';
import adminAPI from '../netlify/functions/admin.mjs';

const ids=['heredity','thermodynamics','codebusters'];
test('all three quizzes have 15 varied questions, five per topic, 50 points',()=>{
 for(const id of ids){const q=getQuiz(id);assert.equal(q.questions.length,15);assert.equal(q.questions.reduce((n,x)=>n+x.points,0),50);assert.deepEqual(q.questions.map(x=>x.points),[2,2,2,2,2,3,3,3,3,3,5,5,5,5,5]);for(const topic of q.topics)assert.equal(q.questions.filter(x=>x.topic===topic).length,5);}
});
test('public questions never reveal solutions or scoring secrets',()=>{
 for(const id of ids){const publicData=publicQuiz(getQuiz(id));for(const q of publicData.questions){assert.ok(!Object.hasOwn(q,'correct'));assert.ok(!Object.hasOwn(q,'answer'));assert.ok(!Object.hasOwn(q,'explanation'));assert.ok(!Object.hasOwn(q,'tolerance'));if(q.fields)for(const f of q.fields)assert.ok(!Object.hasOwn(f,'answer'));}}
});
test('exact correct response earns full points across all 45 questions',()=>{
 for(const id of ids)for(const q of getQuiz(id).questions){let answer;if(q.kind==='choice')answer=String(q.correct);else if(q.kind==='multi')answer=q.correct.map(String);else if(q.kind==='fields')answer=q.fields.map(f=>String(f.answer));else answer=String(q.answer);assert.equal(scoreQuestion(q,answer).earned,q.points,`${id} Q${q.number}`);}
});
test('empty answers earn zero on every question',()=>{for(const id of ids){const g=grade(getQuiz(id),{});assert.equal(g.earned_points,0);assert.equal(g.max_points,50);}});
test('multi-select awards partial points but penalizes false selections',()=>{
 const q=getQuiz('heredity').questions[4];assert.equal(scoreQuestion(q,['0','1','2']).earned,2);assert.equal(scoreQuestion(q,['0','1']).earned,1.333);assert.equal(scoreQuestion(q,['0','1','3']).earned,.667);
});
test('cipher scoring tolerates spacing and case, gives partial letter credit',()=>{
 const q=getQuiz('codebusters').questions[0];assert.equal(scoreQuestion(q,q.answer.toLowerCase()+'!!').earned,q.points);
 const wrong=q.answer.replace(/A/g,'Z');assert.ok(scoreQuestion(q,wrong).earned<q.points);
 assert.equal(normalizeLetters('JuMp, ij!'),'IUMPII');
 const partial='PRACTICE_____PATTERNS_____';assert.ok(scoreQuestion(q,partial).earned>0);
});
test('numeric tolerances, signs, and multipart credit are respected',()=>{
 const entropy=getQuiz('thermodynamics').questions[14];assert.equal(scoreQuestion(entropy,['-0.167','IMPOSSIBLE']).earned,5);assert.equal(scoreQuestion(entropy,['-0.167','POSSIBLE']).earned,2.5);assert.equal(scoreQuestion(entropy,['0.167','IMPOSSIBLE']).earned,2.5);
 assert.equal(scoreQuestion(getQuiz('thermodynamics').questions[8],'-0.5').earned,0);
});
test('valid API GET delivers no private keys',async()=>{
 const r=await quizAPI(new Request('http://local/.netlify/functions/quiz?id=heredity'));assert.equal(r.status,200);const body=await r.json();assert.equal(body.questions.length,15);assert.ok(!JSON.stringify(body).includes('"correct"'));
});
test('local preview permits multiple attempts and protects owner records',async()=>{
 process.env.LOCAL_DEMO='1';delete process.env.NETLIFY;demoAttempts.length=0;
 const data={studentName:'Sample Student',quizId:'heredity',version:BANK.version,answers:{h01:'0'}};
 const post=()=>submitAPI(new Request('http://local/.netlify/functions/submit',{method:'POST',body:JSON.stringify(data)}));
 const a=await post(),b=await post();assert.equal(a.status,200);assert.equal(b.status,200);assert.equal(demoAttempts.length,2);
 const unauth=await adminAPI(new Request('http://local/.netlify/functions/admin'));assert.equal(unauth.status,401);
 const login=await authAPI(new Request('http://local/.netlify/functions/auth',{method:'POST',body:JSON.stringify({action:'login',email:'demo@example.com',password:'demo'})}));const sess=await login.json();assert.equal(login.status,200);
 const admin=await adminAPI(new Request('http://local/.netlify/functions/admin',{headers:{Authorization:'Bearer '+sess.access_token}}));assert.equal(admin.status,200);assert.equal((await admin.json()).attempts.length,2);
});
