# SO Lab — Weekly Science Olympiad Quiz Portal

**3 original, 15-question weekly Division B practice quizzes + a private scores dashboard.**

- Public student quizzes: `/quiz/heredity`, `/quiz/thermodynamics`, `/quiz/codebusters`
- Private owner dashboard: `/dashboard`
- 45 original questions; progressive difficulty; each event = **50 possible points** (basic 2 each, intermediate 3 each, advanced 5 each).
- Heredity: gene expression, PCR, population genetics.
- Thermodynamics: zeroth, first, and second laws (written portion only).
- Codebusters: Aristocrats, 5×5 checkerboard, four-band homophonic, with optional decoding scratchpad.
- Numerical answers with tolerance where stated, sequence/cipher position-by-position partial credit, multi-part independent scoring, and multi-select partial credit with deductions for incorrect selections.
- Students enter their name and may submit any number of separate attempts. Student feedback appears **only after the entire quiz is submitted**.
- Supabase database stores every score and individual answer; owner is authenticated with Supabase Auth and `ADMIN_USER_ID`. Only protected Netlify server functions can read student results or grade answers.
- Dashboard: submission history, event averages, weakest questions/concepts, filters, individual attempt review, and CSV export.

## 1. Preview locally, without accounts

Requirements: Node.js 20 or newer.

```bash
npm run dev
```

Open **http://127.0.0.1:8888/**. Quiz submissions are saved **in memory** for this local-only preview and disappear when the server stops. The demo dashboard is **http://127.0.0.1:8888/dashboard** with `demo@example.com` and password `demo`. **This demo login is not enabled when deployed on Netlify.**

You can run automated checks:

```bash
npm run check
npm test
```

## 2. Set up Supabase

1. Create a new project at [Supabase](https://supabase.com/).
2. Open **SQL Editor** and run the entire `schema.sql` file. It creates `public.quiz_attempts`, enables Row Level Security (RLS), and deliberately creates **no anonymous/authenticated read/write policies**. Database records are accessed only through trusted server-side code with the service-role key.
3. In **Authentication → Users**, create or invite **your own admin user** with an email and a strong password; confirm the email as necessary. Copy that user's **UUID**. The website does **not** support student sign-up (students only enter a name).
4. In **Project Settings → API Keys** (or the corresponding current settings screen), find the Supabase project URL, the **legacy anon API key**, and **legacy service_role key**. These should correspond to the same project. Do **not** put the service role key in your public repo, public code, or the browser.
5. If your Supabase project is configured to block password-based authentication, enable email/password sign-in in Authentication settings. This app uses an email/password administrator login and explicitly checks the authenticated user's UUID server-side on *every* dashboard request.

### SQL security note

`quiz_attempts` is protected by RLS, with no policies granting student/anon access. The trusted Netlify server holds the service-role key, grades responses, writes submissions, and fetches protected dashboard data. Access to the dashboard requires a valid Supabase Auth session **and** an exact match to `ADMIN_USER_ID`. This is a secure access-control design, but without student accounts students can impersonate names; names are *not* verified identities.

## 3. Deploy with Netlify (recommended: Git repository)

1. Unzip this project. Put the **contents** in a new private or public GitHub repository. Keep your `.env` and any keys **out** of the repository. The `.gitignore` protects typical `.env` files.
2. In [Netlify](https://app.netlify.com/), choose **Add new project → Import an existing project**, choose that repository, and deploy. `netlify.toml` already defines the publish directory as `public` and functions directory as `netlify/functions`. **Do not use Netlify's static-only drag-and-drop deploy**; the API functions must also be deployed.
3. In **Site configuration → Environment variables**, add these four variables **exactly** (mark secret values as sensitive if your Netlify plan provides that control):

   | Environment variable | Value |
   | --- | --- |
   | `SUPABASE_URL` | `https://<your-project>.supabase.co` |
   | `SUPABASE_ANON_KEY` | Supabase legacy anon key |
   | `SUPABASE_SERVICE_ROLE_KEY` | Supabase secret service_role key; **server only** |
   | `ADMIN_USER_ID` | UUID of the admin Auth user created in Step 2 |

4. **Trigger a new deploy** after adding variables so that Netlify Functions receive them.
5. Test public pages: `https://<your-site>.netlify.app/quiz/heredity`, `/quiz/thermodynamics`, and `/quiz/codebusters`. Then test `/dashboard` using your Supabase admin email and password.
6. Submit a short test attempt and confirm it appears in the owner dashboard. Repeat to confirm all attempts are retained. You can delete your test submissions in Supabase **Table Editor** or via SQL if desired.

Netlify automatically bundles `.mjs` server functions; no third-party npm dependencies are needed for the runtime. Do not publish the private bank in the static `public/` directory. The bank is only bundled into the deployed server functions.

### Things to check if a page doesn't work

- **Quiz loading error / 404 on API:** Make sure Netlify actually deployed the functions. Check `/.netlify/functions/quiz?id=heredity` and Netlify's function logs.
- **Submit error about database configuration:** Set all environment variables and redeploy; run `schema.sql`.
- **Permission error on login:** The Supabase admin Auth user's UUID must exactly match `ADMIN_USER_ID`; the account must be active.
- **Login rejected:** Confirm that email/password auth is enabled, the email is confirmed, and you entered the right password.
- **Score saved but dashboard appears empty:** Verify both functions are pointing to the same Supabase project; refresh.
- **Netlify 404 on `/quiz/heredity`:** Check the `[[redirects]]` rules in `netlify.toml` and redeploy.

## Privacy, integrity, and known limitations

- Store only student names and assessment data, not email addresses, locations or dates of birth. Follow your school's policies for student records and parent notices/consent, where applicable.
- For a small team this architecture should be appropriate, but site owners should consider CAPTCHA/Turnstile or rate limiting if sharing quizzes publicly with untrusted internet traffic. There is no hard anti-bot limit in this first version.
- Retakes are unlimited. Names are self-reported; a student can intentionally use a different name. Do not use this for high-stakes identity verification.
- Cipher grading ignores case, spaces and ordinary punctuation; use underscores for unknown-letter positions. It awards fractional marks for characters in the correct positions. Insertions/deletions shift subsequent positions, which can reduce credit. Multi-select earns `(correct selected − incorrect selected) / total correct`, clamped between 0% and 100%. Multi-part entries are equally weighted within a question. Numerical questions require correct values within the defined tolerance; no error-based partial credit on an individual numerical entry.
- The app supplies competition-style information and references, but **online computer entry itself is a practice accommodation**, not proof that electronics are permitted in a physical contest. Thermodynamics device testing isn't replicated. For rules or clarification changes, the official [Science Olympiad](https://www.soinc.org/) policies supersede this training quiz.
- The first Codebusters cipher is not automatically timed because this week's quizzes are deliberately untimed. Timed Aristocrat bonuses can be added in a future version.
- The owner dashboard loads up to 10,000 most recent attempts per refresh. It is intended for a team, not a large production gradebook. Sessions are stored in tab-local `sessionStorage` and renewed using the Supabase refresh token. Avoid sharing an unlocked admin computer.
- Because correct answers become available after any submitted attempt, this is a learning portal, not a tamper-resistant proctored exam.

## Project structure

```
public/                  Static website (publicly deployed)
  index.html             3-quiz home page
  quiz.html, app.js      Student quiz interface and answer review
  admin.html, admin.js   Secure owner login, analytics, CSV export
  styles.css             Responsive dark theme
netlify/functions/       Server-side endpoints (not publicly readable source)
  quiz.mjs               Returns student-safe question data
  submit.mjs             Secure grading + records all attempts
  auth.mjs               Supabase password login and token refresh
  admin.mjs              Authorized submission history API
  _lib/bank.mjs          Private 45-question answer bank
  _lib/core.mjs          Grading + DB/auth utilities
schema.sql               Database tables and Row Level Security
netlify.toml             Hosting, function routing and security headers
make_bank.py             Question bank source generator (optional)
tests/                   Grading and API checks
```

**This project has not been deployed to the user's Netlify/Supabase accounts**; deployment requires the account owner to connect their own services and add four secure environment variables.
