/* Local-only preview server. Run npm run dev then visit http://127.0.0.1:8888
   IMPORTANT: this simulator is never included in Netlify's public publish directory. */
import http from 'node:http';
import {readFile,stat} from 'node:fs/promises';
import {resolve,extname} from 'node:path';
const path=resolve('./public');
process.env.LOCAL_DEMO='1';
const types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.json':'application/json'};
const handlers={};for(const name of ['quiz','submit','auth','admin'])handlers[name]=(await import(`./netlify/functions/${name}.mjs`)).default;
const server=http.createServer(async(req,res)=>{try{
 const target=new URL(req.url,'http://127.0.0.1:8888');
 if(target.pathname.startsWith('/.netlify/functions/')){
   const name=target.pathname.split('/')[3];if(!handlers[name]){res.writeHead(404);res.end('Unknown API');return;}
   const bufs=[];for await(const chunk of req){bufs.push(chunk);if(Buffer.concat(bufs).length>60000)throw new Error('Request too large');}
   const request=new Request(target,{method:req.method,headers:req.headers,body:['POST','PUT','PATCH'].includes(req.method)?Buffer.concat(bufs):undefined});
   const reply=await handlers[name](request);res.writeHead(reply.status,Object.fromEntries(reply.headers));res.end(Buffer.from(await reply.arrayBuffer()));return;
 }
 let file=target.pathname==='/'?'index.html':target.pathname==='/dashboard'?'admin.html':/^\/quiz\/(heredity|thermodynamics|codebusters)$/.test(target.pathname)?'quiz.html':target.pathname.slice(1);
 const location=resolve(path,file);
 if(location!==path&&!location.startsWith(path+'/'))throw new Error('Forbidden');
 const s=await stat(location);if(!s.isFile())throw new Error('No file');
 res.writeHead(200,{'Content-Type':types[extname(location)]||'application/octet-stream','X-Content-Type-Options':'nosniff'});res.end(await readFile(location));
}catch(e){res.writeHead(404);res.end('Not found: '+e.message);}});
server.listen(8888,'127.0.0.1',()=>console.log('Local demo: http://127.0.0.1:8888 | Dashboard demo@example.com / demo')); 
