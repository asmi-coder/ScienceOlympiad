import {json,requireJson,sbRequest,demo,errorResponse} from './_lib/core.mjs';
export default async function(request){
  if(request.method!=='POST')return json({error:'Method not allowed'},405);
  try{
    const input=await requireJson(request,12000);
    if(demo()){
      if(input.action==='login' && input.email==='demo@example.com' && input.password==='demo')return json({access_token:'demo-local-token',refresh_token:'demo-refresh-token',expires_at:Date.now()/1000+3600,email:'demo@example.com'});
      if(input.action==='refresh'&&input.refresh_token==='demo-refresh-token')return json({access_token:'demo-local-token',refresh_token:'demo-refresh-token',expires_at:Date.now()/1000+3600,email:'demo@example.com'});
      return json({error:'Demo login: demo@example.com / demo'},401);
    }
    let response;
    if(input.action==='login'){
      if(typeof input.email!=='string'||typeof input.password!=='string'||input.password.length>300)return json({error:'Enter valid credentials'},400);
      response=await sbRequest('/auth/v1/token?grant_type=password',{method:'POST',auth:'anon',body:{email:input.email,password:input.password}});
    }else if(input.action==='refresh'){
      if(typeof input.refresh_token!=='string')return json({error:'Invalid session'},400);
      response=await sbRequest('/auth/v1/token?grant_type=refresh_token',{method:'POST',auth:'anon',body:{refresh_token:input.refresh_token}});
    }else return json({error:'Unsupported action'},400);
    const user=await sbRequest('/auth/v1/user',{auth:'anon',bearer:response.access_token});
    if(!process.env.ADMIN_USER_ID||user.id!==process.env.ADMIN_USER_ID)return json({error:'Account is not authorized as quiz administrator'},403);
    return json({access_token:response.access_token,refresh_token:response.refresh_token,expires_at:response.expires_at||Math.floor(Date.now()/1000)+response.expires_in,email:user.email});
  }catch(e){return errorResponse(e);}
}
