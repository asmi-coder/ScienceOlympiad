// Private server-side question bank. Do not copy into /public.
export const BANK = {
  "version": "2026-week1-v1",
  "quizzes": {
    "heredity": {
      "title": "Heredity",
      "subtitle": "DNA expression · PCR · Population genetics",
      "color": "mint",
      "materials": "2027 Division B: up to two Class II calculators and one double-sided 8.5 × 11 in. notes sheet per team.",
      "topics": [
        "Transcription & translation",
        "PCR & biotechnology",
        "Population genetics"
      ],
      "questions": [
        {
          "id": "h01",
          "number": 1,
          "level": "basic",
          "points": 2,
          "topic": "Transcription & translation",
          "kind": "choice",
          "prompt": "A DNA template strand reads 3′–TAC GGA ACT–5′. What mRNA is transcribed (5′→3′)?",
          "explanation": "RNA polymerase reads the DNA template 3′→5′ and builds the complementary mRNA 5′→3′: TAC→AUG, GGA→CCU, ACT→UGA.",
          "options": [
            "5′–AUG CCU UGA–3′",
            "5′–UAC GGA ACU–3′",
            "3′–AUG CCU UGA–5′",
            "5′–ATG CCT TGA–3′"
          ],
          "correct": 0
        },
        {
          "id": "h02",
          "number": 2,
          "level": "basic",
          "points": 2,
          "topic": "PCR & biotechnology",
          "kind": "choice",
          "prompt": "In a standard PCR cycle, what is the main purpose of heating a sample to about 95°C?",
          "explanation": "High heat breaks hydrogen bonds between DNA strands (denaturation). Primers anneal at a lower temperature, and thermostable polymerase extends DNA at its optimal temperature.",
          "options": [
            "To separate the two DNA strands",
            "To attach primers to the template",
            "To synthesize the complementary DNA",
            "To cut DNA at restriction sites"
          ],
          "correct": 0
        },
        {
          "id": "h03",
          "number": 3,
          "level": "basic",
          "points": 2,
          "topic": "Population genetics",
          "kind": "choice",
          "prompt": "Which condition is required for the simple Hardy–Weinberg model to maintain constant allele frequencies?",
          "explanation": "Hardy–Weinberg assumes random mating, a very large population, and no mutation, migration, or selection. Strong migration would change allele frequencies.",
          "options": [
            "Random mating and no migration",
            "A small population with frequent drift",
            "Strong selection favoring one genotype",
            "A high rate of new mutations"
          ],
          "correct": 0
        },
        {
          "id": "h04",
          "number": 4,
          "level": "basic",
          "points": 2,
          "topic": "Transcription & translation",
          "kind": "sequence",
          "prompt": "The DNA coding strand is 5′–ATG CCT TAA–3′. Enter the mature mRNA sequence from this region in the 5′→3′ direction. Assume no introns.",
          "explanation": "The coding DNA strand matches mRNA except that U replaces T. Therefore ATG CCT TAA becomes 5′–AUG CCU UAA–3′.",
          "answer": "AUGCCUUAA",
          "label": "mRNA, 5′→3′ (letters only)"
        },
        {
          "id": "h05",
          "number": 5,
          "level": "basic",
          "points": 2,
          "topic": "PCR & biotechnology",
          "kind": "multi",
          "prompt": "Select ALL components needed to amplify a double-stranded DNA target by ordinary PCR.",
          "explanation": "Ordinary PCR requires DNA template, a pair of primers, dNTPs, buffer/Mg²⁺, and a thermostable DNA polymerase. RNA ligase is not part of the standard amplification reaction.",
          "options": [
            "A thermostable DNA polymerase",
            "Deoxyribonucleotide triphosphates (dNTPs)",
            "Forward and reverse DNA primers",
            "RNA ligase to join the primers"
          ],
          "correct": [
            0,
            1,
            2
          ]
        },
        {
          "id": "h06",
          "number": 6,
          "level": "intermediate",
          "points": 3,
          "topic": "Population genetics",
          "kind": "number",
          "prompt": "In a Hardy–Weinberg population, 9% show an autosomal recessive phenotype (aa). What percentage are heterozygous carriers (Aa)? Enter a percentage (not a decimal).",
          "explanation": "q²=0.09, so q=0.30 and p=0.70. Heterozygotes occur at 2pq=2(0.7)(0.3)=0.42, or 42%.",
          "answer": 42,
          "tolerance": 0.05,
          "unit": "%"
        },
        {
          "id": "h07",
          "number": 7,
          "level": "intermediate",
          "points": 3,
          "topic": "Transcription & translation",
          "kind": "choice",
          "prompt": "The DNA template strand is 3′–AAG TCC GTA–5′. The supplied codon information is UUC=Phe, AGG=Arg, CAU=His, AAG=Lys, UCC=Ser. Which peptide is produced if this region is translated in the shown reading frame?",
          "explanation": "The template produces 5′–UUC AGG CAU–3′. Ribosomes read those 5′→3′ codons, producing Phe–Arg–His.",
          "options": [
            "Phe–Arg–His",
            "Lys–Ser–His",
            "Phe–Ser–His",
            "His–Arg–Phe"
          ],
          "correct": 0
        },
        {
          "id": "h08",
          "number": 8,
          "level": "intermediate",
          "points": 3,
          "topic": "PCR & biotechnology",
          "kind": "number",
          "prompt": "A PCR reaction begins with one double-stranded DNA target. Assuming perfect doubling each cycle and ignoring plateau effects, how many double-stranded target copies exist after 7 cycles?",
          "explanation": "Ideal PCR doubles each cycle: 1×2⁷=128 double-stranded molecules. Real experiments may depart from perfect doubling.",
          "answer": 128,
          "tolerance": 0,
          "unit": "copies"
        },
        {
          "id": "h09",
          "number": 9,
          "level": "intermediate",
          "points": 3,
          "topic": "Population genetics",
          "kind": "choice",
          "prompt": "A hurricane randomly kills most of an island's beetles. The survivors have very different allele frequencies even though no color is favored. Which process best explains the change?",
          "explanation": "A population bottleneck changes allele frequencies through chance sampling of survivors. Natural selection would require a consistent fitness difference related to the allele.",
          "options": [
            "Genetic drift via a bottleneck",
            "Directional natural selection",
            "Nonrandom mating alone",
            "An increase in DNA replication accuracy"
          ],
          "correct": 0
        },
        {
          "id": "h10",
          "number": 10,
          "level": "intermediate",
          "points": 3,
          "topic": "Transcription & translation",
          "kind": "choice",
          "prompt": "A coding DNA sequence is 5′–ATG AAA GGC TAA–3′. The first A in the second codon is deleted. What is the best prediction for translation from the original start codon?",
          "explanation": "Deleting one nucleotide changes the reading frame downstream of that position. The new codons begin ATG AAG GCT ... rather than ATG AAA GGC ..., and later stop placement may change.",
          "options": [
            "A frameshift changes downstream codons",
            "Only the second amino acid can change",
            "Every later codon remains the same",
            "The original reading frame is preserved"
          ],
          "correct": 0
        },
        {
          "id": "h11",
          "number": 11,
          "level": "advanced",
          "points": 5,
          "topic": "PCR & biotechnology",
          "kind": "fields",
          "prompt": "A double-stranded PCR target has the top strand 5′–AGTC TTAACG CGAT–3′ (spaces added for readability). Design 4-base primers that flank this whole displayed region. Enter EACH primer 5′→3′.",
          "explanation": "The forward primer equals the top strand's first four bases: AGTC. The reverse primer is the reverse complement of the top strand's last four bases, CGAT → ATCG (written 5′→3′).",
          "fields": [
            {
              "label": "Forward primer, 5′→3′",
              "answer": "AGTC",
              "mode": "sequence"
            },
            {
              "label": "Reverse primer, 5′→3′",
              "answer": "ATCG",
              "mode": "sequence"
            }
          ]
        },
        {
          "id": "h12",
          "number": 12,
          "level": "advanced",
          "points": 5,
          "topic": "Population genetics",
          "kind": "fields",
          "prompt": "In a large Hardy–Weinberg population, the aa phenotype is initially 16%. Migration changes the recessive allele frequency to q=0.25. Calculate (a) the INITIAL recessive allele frequency and (b) the NEW percentage of heterozygotes.",
          "explanation": "Initially q²=0.16, so q=0.40. After migration p=1−0.25=0.75; new 2pq=2(0.75)(0.25)=0.375=37.5%. These are two different time points.",
          "fields": [
            {
              "label": "Initial q (decimal)",
              "answer": 0.4,
              "mode": "number",
              "tolerance": 0.001
            },
            {
              "label": "New heterozygotes (%)",
              "answer": 37.5,
              "mode": "number",
              "tolerance": 0.05
            }
          ]
        },
        {
          "id": "h13",
          "number": 13,
          "level": "advanced",
          "points": 5,
          "topic": "Transcription & translation",
          "kind": "sequence",
          "prompt": "A pre-mRNA contains EXON 1: 5′–AUG–3′, INTRON: 5′–CCAAUGG–3′, EXON 2: 5′–GAAUAA–3′. Assume ordinary splicing removes the entire intron and the exons are joined directly. Enter the mature coding-region mRNA sequence, 5′→3′.",
          "explanation": "RNA splicing removes the intron, not the exons. Joining AUG + GAAUAA produces 5′–AUGGAAUAA–3′, which encodes Met–Glu–Stop.",
          "answer": "AUGGAAUAA",
          "label": "Mature mRNA, letters only"
        },
        {
          "id": "h14",
          "number": 14,
          "level": "advanced",
          "points": 5,
          "topic": "PCR & biotechnology",
          "kind": "number",
          "prompt": "In quantitative PCR (qPCR), sample A reaches the threshold at cycle 18 and sample B at cycle 21. Assuming 100% amplification efficiency and equal thresholds, approximately how many times more starting target DNA did sample A contain than B?",
          "explanation": "A Ct difference of 3 cycles at 100% efficiency means 2³=8-fold more starting template in the earlier-threshold sample (A).",
          "answer": 8,
          "tolerance": 0.05,
          "unit": "fold"
        },
        {
          "id": "h15",
          "number": 15,
          "level": "advanced",
          "points": 5,
          "topic": "Population genetics",
          "kind": "number",
          "prompt": "Before viability selection, a population has 400 AA, 400 Aa and 200 aa individuals. Survival to breeding is 100% for AA, 75% for Aa and 50% for aa. What is the recessive allele frequency q among the SURVIVORS? Give a decimal to 4 places.",
          "explanation": "Survivors: AA=400, Aa=300, aa=100 (800 total). Recessive alleles=300+2(100)=500; total alleles=2(800)=1600, so q=500/1600=0.3125. Do not assume Hardy–Weinberg after selection.",
          "answer": 0.3125,
          "tolerance": 5e-05,
          "unit": "decimal"
        }
      ]
    },
    "thermodynamics": {
      "title": "Thermodynamics",
      "subtitle": "Zeroth law · First law · Second law",
      "color": "amber",
      "materials": "2027 Division B: up to two Class III calculators and permitted printed resources per team. This is written-test practice, not device testing.",
      "topics": [
        "Zeroth law & equilibrium",
        "First law & energy",
        "Second law & entropy"
      ],
      "questions": [
        {
          "id": "t01",
          "number": 1,
          "level": "basic",
          "points": 2,
          "topic": "Zeroth law & equilibrium",
          "kind": "choice",
          "prompt": "Object A and object B are each separately in thermal equilibrium with a calibrated thermometer C. What does the Zeroth Law imply about A and B?",
          "explanation": "The Zeroth Law makes thermal equilibrium transitive. If A and C share a temperature and B and C share a temperature, then A and B share a temperature.",
          "options": [
            "They have the same temperature",
            "They must have the same internal energy",
            "They must have the same mass",
            "They must transfer heat at the same rate"
          ],
          "correct": 0
        },
        {
          "id": "t02",
          "number": 2,
          "level": "basic",
          "points": 2,
          "topic": "First law & energy",
          "kind": "number",
          "prompt": "A gas absorbs 450 J of heat and does 150 J of work on the surroundings. Using ΔU=Q−W_by, find ΔU in joules.",
          "explanation": "Q=+450 J and W_by=+150 J, so ΔU=450−150=+300 J. Expansion work done BY the gas reduces its internal energy relative to the absorbed heat.",
          "answer": 300,
          "tolerance": 0.01,
          "unit": "J"
        },
        {
          "id": "t03",
          "number": 3,
          "level": "basic",
          "points": 2,
          "topic": "Second law & entropy",
          "kind": "choice",
          "prompt": "A cyclic engine takes heat from a single thermal reservoir and claims to convert all of it into net work with no other effect. Which statement is correct?",
          "explanation": "The Kelvin–Planck statement of the Second Law forbids a cyclic engine from converting all heat extracted from one reservoir entirely into work without another effect.",
          "options": [
            "It violates the Second Law",
            "It is possible if friction is zero",
            "It violates only the Zeroth Law",
            "It is possible at sufficiently high pressure"
          ],
          "correct": 0
        },
        {
          "id": "t04",
          "number": 4,
          "level": "basic",
          "points": 2,
          "topic": "Zeroth law & equilibrium",
          "kind": "number",
          "prompt": "A sensor measures 27.0°C. Convert this temperature to kelvin using T(K)=T(°C)+273.15. Enter the numerical value.",
          "explanation": "27.0+273.15=300.15 K. A temperature difference of 1°C equals a difference of 1 K, but the zero points differ.",
          "answer": 300.15,
          "tolerance": 0.01,
          "unit": "K"
        },
        {
          "id": "t05",
          "number": 5,
          "level": "basic",
          "points": 2,
          "topic": "First law & energy",
          "kind": "choice",
          "prompt": "An ideal gas is compressed adiabatically. The surroundings do 300 J of work ON the gas and there is no heat exchange. What is the internal energy change?",
          "explanation": "With ΔU=Q+W_on, Q=0 (adiabatic) and W_on=+300 J, so ΔU=+300 J. Work done ON the gas increases internal energy.",
          "options": [
            "+300 J",
            "−300 J",
            "0 J",
            "+600 J"
          ],
          "correct": 0
        },
        {
          "id": "t06",
          "number": 6,
          "level": "intermediate",
          "points": 3,
          "topic": "Second law & entropy",
          "kind": "number",
          "prompt": "An ideal reversible heat engine operates between 600 K and 300 K reservoirs. Calculate the maximum Carnot efficiency as a percentage.",
          "explanation": "η_C=1−T_c/T_h=1−300/600=0.50=50%. Temperatures must be in kelvin.",
          "answer": 50,
          "tolerance": 0.05,
          "unit": "%"
        },
        {
          "id": "t07",
          "number": 7,
          "level": "intermediate",
          "points": 3,
          "topic": "Zeroth law & equilibrium",
          "kind": "multi",
          "prompt": "Select ALL intensive thermodynamic properties from this list (for a uniform equilibrium sample).",
          "explanation": "Temperature and pressure are intensive; their values do not scale with sample size. Mass and volume are extensive and add when combining samples.",
          "options": [
            "Temperature",
            "Mass",
            "Pressure",
            "Volume"
          ],
          "correct": [
            0,
            2
          ]
        },
        {
          "id": "t08",
          "number": 8,
          "level": "intermediate",
          "points": 3,
          "topic": "First law & energy",
          "kind": "number",
          "prompt": "A heat engine completes one cycle, absorbs 1200 J from a hot reservoir and rejects 850 J to a cold reservoir. What is its net work output per cycle?",
          "explanation": "For a full cycle ΔU=0. Therefore W_net=Q_in−Q_out=1200−850=350 J.",
          "answer": 350,
          "tolerance": 0.01,
          "unit": "J"
        },
        {
          "id": "t09",
          "number": 9,
          "level": "intermediate",
          "points": 3,
          "topic": "Second law & entropy",
          "kind": "number",
          "prompt": "An amount of 600 J of heat flows directly from a 400 K reservoir to a 300 K reservoir. Assume their temperatures stay constant. Find the total entropy change of the two reservoirs in J/K.",
          "explanation": "The hot reservoir loses 600 J: ΔS_hot=−600/400=−1.5 J/K. The cold gains 600 J: ΔS_cold=+600/300=+2.0 J/K. Total ΔS=+0.5 J/K.",
          "answer": 0.5,
          "tolerance": 0.01,
          "unit": "J/K"
        },
        {
          "id": "t10",
          "number": 10,
          "level": "intermediate",
          "points": 3,
          "topic": "Zeroth law & equilibrium",
          "kind": "choice",
          "prompt": "Two insulated copper blocks are initially at exactly 40°C, but block A has twice the mass of block B. They are put in good thermal contact. What occurs after they equilibrate?",
          "explanation": "They already have equal temperatures, so no net heat transfer occurs solely because the blocks have different masses. A does have more thermal energy relative to an equal reference temperature, but temperature sets heat-flow direction.",
          "options": [
            "No net heat flows between the blocks",
            "Net heat flows from A to B because A is heavier",
            "Net heat flows from B to A because B is lighter",
            "Both blocks must settle at 20°C"
          ],
          "correct": 0
        },
        {
          "id": "t11",
          "number": 11,
          "level": "advanced",
          "points": 5,
          "topic": "First law & energy",
          "kind": "number",
          "prompt": "In an insulated container, 0.20 kg of water at 80°C is mixed with 0.30 kg of water at 20°C. Assume no heat loss or phase change and equal specific heat for both samples. What is the final equilibrium temperature in °C?",
          "explanation": "Conservation of energy: 0.20(80−T)=0.30(T−20). Thus 16−0.2T=0.3T−6, so 22=0.5T and T=44°C.",
          "answer": 44,
          "tolerance": 0.05,
          "unit": "°C"
        },
        {
          "id": "t12",
          "number": 12,
          "level": "advanced",
          "points": 5,
          "topic": "Second law & entropy",
          "kind": "fields",
          "prompt": "A heat engine takes 2000 J from an 800 K reservoir, produces 900 J of work, and rejects the remaining heat to a 300 K reservoir per cycle. Find (a) rejected heat and (b) total entropy change of the reservoirs. Round entropy to 3 decimals.",
          "explanation": "Energy conservation gives Q_c=2000−900=1100 J. Total reservoir entropy is −2000/800+1100/300=−2.5+3.6667≈+1.167 J/K. Positive entropy production is consistent with the Second Law.",
          "fields": [
            {
              "label": "Heat rejected (J)",
              "answer": 1100,
              "mode": "number",
              "tolerance": 0.1
            },
            {
              "label": "Net reservoir entropy (J/K)",
              "answer": 1.167,
              "mode": "number",
              "tolerance": 0.001
            }
          ]
        },
        {
          "id": "t13",
          "number": 13,
          "level": "advanced",
          "points": 5,
          "topic": "Zeroth law & equilibrium",
          "kind": "fields",
          "prompt": "A resistance thermometer is calibrated as R(Ω)=100+0.40T(°C). It reads 120 Ω for block A and the same 120 Ω for block B, but 128 Ω for block C. Find (a) A's temperature and (b) C's temperature in °C. Which way would heat flow when B touches C?",
          "explanation": "Solve T=(R−100)/0.40. A and B are at 50°C; C is at 70°C. Heat flows spontaneously from C to B until equilibrium. The Zeroth Law says A and B are already mutually in equilibrium.",
          "fields": [
            {
              "label": "Block A temperature (°C)",
              "answer": 50,
              "mode": "number",
              "tolerance": 0.05
            },
            {
              "label": "Block C temperature (°C)",
              "answer": 70,
              "mode": "number",
              "tolerance": 0.05
            },
            {
              "label": "Heat flows from (letter)",
              "answer": "C",
              "mode": "text"
            }
          ]
        },
        {
          "id": "t14",
          "number": 14,
          "level": "advanced",
          "points": 5,
          "topic": "First law & energy",
          "kind": "fields",
          "prompt": "At constant external pressure 100 kPa, a gas expands from 0.0020 m³ to 0.0050 m³ while absorbing 900 J of heat. Find (a) work done BY the gas and (b) ΔU. Use SI units.",
          "explanation": "W_by=PΔV=(100000 Pa)(0.0030 m³)=300 J. First Law: ΔU=Q−W_by=900−300=600 J. One Pa·m³ equals one joule.",
          "fields": [
            {
              "label": "Work done by the gas (J)",
              "answer": 300,
              "mode": "number",
              "tolerance": 0.1
            },
            {
              "label": "Change in internal energy (J)",
              "answer": 600,
              "mode": "number",
              "tolerance": 0.1
            }
          ]
        },
        {
          "id": "t15",
          "number": 15,
          "level": "advanced",
          "points": 5,
          "topic": "Second law & entropy",
          "kind": "fields",
          "prompt": "A proposed cyclic engine absorbs 1000 J from a 500 K source and claims to output 450 J of work while rejecting the rest to a 300 K sink. Calculate (a) total entropy change of the reservoirs (J/K, 3 decimals) and (b) whether the engine is physically possible as described. Enter POSSIBLE or IMPOSSIBLE.",
          "explanation": "Q_c=1000−450=550 J. Reservoir entropy: −1000/500+550/300=−2+1.8333≈−0.167 J/K. Since total entropy decreases, the device violates the Second Law; Carnot efficiency is only 40%, less than the claimed 45%.",
          "fields": [
            {
              "label": "Reservoir entropy change (J/K)",
              "answer": -0.167,
              "mode": "number",
              "tolerance": 0.001
            },
            {
              "label": "POSSIBLE or IMPOSSIBLE",
              "answer": "IMPOSSIBLE",
              "mode": "text"
            }
          ]
        }
      ]
    },
    "codebusters": {
      "title": "Codebusters",
      "subtitle": "Aristocrats · Checkerboard · Homophonic",
      "color": "purple",
      "materials": "2027 Division B: writing utensils only; supervisor supplies relevant cipher reference tables. No calculator or personal reference sheet.",
      "topics": [
        "Aristocrat substitutions",
        "5×5 checkerboard",
        "Homophonic ciphers"
      ],
      "questions": [
        {
          "id": "c01",
          "number": 1,
          "level": "basic",
          "points": 2,
          "topic": "Aristocrat substitutions",
          "kind": "cipher",
          "prompt": "Decrypt the following aristocrat message. Enter the entire plaintext sentence. Punctuation and spaces will not affect grading.",
          "explanation": "The decoded message is “PRACTICE MAKES PATTERNS CLEAR.” Substitution is one-to-one throughout the question, so repeated cipher letters always stand for repeated plaintext letters. Use word lengths, frequency, and confirmed mappings to complete the alphabet.",
          "answer": "PRACTICE MAKES PATTERNS CLEAR",
          "ciphertext": "TPXVLGVK WXAKF TXLLKPJF VHKXP",
          "resource": "Provided full alphabet (plaintext→ciphertext): ABCDEFGHIJKLMNOPQRSTUVWXYZ → XSVQKOEMGIAHWJUTBPFLRCYZDN. Read the mapping in reverse to decrypt.",
          "workbench": "letters"
        },
        {
          "id": "c02",
          "number": 2,
          "level": "basic",
          "points": 2,
          "topic": "5×5 checkerboard",
          "kind": "cipher",
          "prompt": "Decrypt the following checkerboard message. Enter the entire plaintext sentence. Punctuation and spaces will not affect grading.",
          "explanation": "The original message is “PACK MY BOX WITH FIVE DOZEN LIQUOR JUGS.” Construct the 5×5 keyed Polybius square; each pair identifies one row and one column using the separate row and column keys. I/J use the same square cell.",
          "answer": "PACK MY BOX WITH FIVE DOZEN LIQUOR JUGS",
          "ciphertext": "GR RO GW EO / ED TD / RR AW TR / TO GO AD GD / RS GO TW GS / RD AW TS GS ES / ER GO AO AS AW RW / GO AS EW AR",
          "resource": "Polybius key: CIPHER. Row-key letters: GREAT. Column-key letters: WORDS. The 5×5 grid (rows top to bottom): C I P H E / R A B D F / G K L M N / O Q S T U / V W X Y Z. Read each pair as row letter then column letter.",
          "workbench": "pairs"
        },
        {
          "id": "c03",
          "number": 3,
          "level": "basic",
          "points": 2,
          "topic": "Homophonic ciphers",
          "kind": "cipher",
          "prompt": "Decrypt the following homophonic message. Enter the entire plaintext sentence. Punctuation and spaces will not affect grading.",
          "explanation": "The four-letter keyword is LAMP; the recovered plaintext is “SOLVE THE CODE ONE STEP AT A TIME.” Each number belongs to one of four 25-number bands. Start each band at its keyword letter and advance through the 25-letter I/J-combined alphabet, wrapping around. Subtract the band start to obtain the alphabet offset; keep the same offset from the band's keyword letter.",
          "answer": "SOLVE THE CODE ONE STEP AT A TIME",
          "ciphertext": "79 00 97 46 69 / 09 33 30 / 18 00 68 20 / 39 52 69 / 79 44 91 05 / 16 09 / 87 / 58 34 51 30",
          "resource": "Four-band homophonic cipher; known keyword letters (in order): LAMP. Each 25-number band (01–25, 26–50, 51–75, 76–00) maps its FIRST number to the corresponding keyword letter, then continues alphabetically through ABCDEFGHIKLMNOPQRSTUVWXYZ, wrapping around. The token 00 denotes 100. Each plaintext letter can use any of its four band numbers. Spaces/slashes separate words.",
          "workbench": "tokens"
        },
        {
          "id": "c04",
          "number": 4,
          "level": "basic",
          "points": 2,
          "topic": "Aristocrat substitutions",
          "kind": "cipher",
          "prompt": "Decrypt the following aristocrat message. Enter the entire plaintext sentence. Punctuation and spaces will not affect grading.",
          "explanation": "The decoded message is “EVERY LETTER HAS A PLACE IN THE PUZZLE.” Substitution is one-to-one throughout the question, so repeated cipher letters always stand for repeated plaintext letters. Use word lengths, frequency, and confirmed mappings to complete the alphabet.",
          "answer": "EVERY LETTER HAS A PLACE IN THE PUZZLE",
          "ciphertext": "VDVNT PVLLVN XRJ R ZPRWV KM LXV ZIOOPV",
          "resource": "Provided full alphabet (plaintext→ciphertext): ABCDEFGHIJKLMNOPQRSTUVWXYZ → RSWAVQCXKHGPUMBZENJLIDYFTO. Read the mapping in reverse to decrypt.",
          "workbench": "letters"
        },
        {
          "id": "c05",
          "number": 5,
          "level": "basic",
          "points": 2,
          "topic": "5×5 checkerboard",
          "kind": "cipher",
          "prompt": "Decrypt the following checkerboard message. Enter the entire plaintext sentence. Punctuation and spaces will not affect grading.",
          "explanation": "The original message is “QUICK VEXED WIZARDS PACK MY BOX WITH JUGS.” Construct the 5×5 keyed Polybius square; each pair identifies one row and one column using the separate row and column keys. I/J use the same square cell.",
          "answer": "QUICK VEXED WIZARDS PACK MY BOX WITH JUGS",
          "ciphertext": "AR AS GD RO ER / TW RD TR RD RR / TO GD TS RW GO RR AD / AO RW RO ER / ES TD / GR GW TR / TO GD GS EO / GD AS EW AD",
          "resource": "Polybius key: ORBIT. Row-key letters: GREAT. Column-key letters: WORDS. The 5×5 grid (rows top to bottom): O R B I T / A C D E F / G H K L M / N P Q S U / V W X Y Z. Read each pair as row letter then column letter.",
          "workbench": "pairs"
        },
        {
          "id": "c06",
          "number": 6,
          "level": "intermediate",
          "points": 3,
          "topic": "Homophonic ciphers",
          "kind": "cipher",
          "prompt": "Decrypt the following homophonic message. Enter the entire plaintext sentence. Punctuation and spaces will not affect grading.",
          "explanation": "The four-letter keyword is MINT; the recovered plaintext is “THE BEST CLUE OFTEN HIDES IN PLAIN SIGHT.” Each number belongs to one of four 25-number bands. Start each band at its keyword letter and advance through the 25-letter I/J-combined alphabet, wrapping around. Subtract the band start to obtain the alphabet offset; keep the same offset from the band's keyword letter.",
          "answer": "THE BEST CLUE OFTEN HIDES IN PLAIN SIGHT",
          "ciphertext": "76 50 68 / 44 87 00 08 / 17 74 09 68 / 52 88 36 87 02 / 71 23 67 68 56 / 91 51 / 32 93 64 23 95 / 56 72 49 22 76",
          "resource": "Four-band homophonic cipher; known keyword letters (in order): MINT. Each 25-number band (01–25, 26–50, 51–75, 76–00) maps its FIRST number to the corresponding keyword letter, then continues alphabetically through ABCDEFGHIKLMNOPQRSTUVWXYZ, wrapping around. The token 00 denotes 100. Each plaintext letter can use any of its four band numbers. Spaces/slashes separate words.",
          "workbench": "tokens"
        },
        {
          "id": "c07",
          "number": 7,
          "level": "intermediate",
          "points": 3,
          "topic": "Aristocrat substitutions",
          "kind": "cipher",
          "prompt": "Decrypt the following aristocrat message. Enter the entire plaintext sentence. Punctuation and spaces will not affect grading.",
          "explanation": "The decoded message is “A SHORT WORD CAN REVEAL A VERY LONG SECRET MESSAGE.” Substitution is one-to-one throughout the question, so repeated cipher letters always stand for repeated plaintext letters. Use word lengths, frequency, and confirmed mappings to complete the alphabet.",
          "answer": "A SHORT WORD CAN REVEAL A VERY LONG SECRET MESSAGE",
          "ciphertext": "K BAMGI CMGZ JKS GNRNKE K RNGL EMSO BNJGNI WNBBKON",
          "resource": "Known plaintext→ciphertext pairs: E→N, T→I, A→K, H→A. Other mappings must be inferred from word patterns.",
          "workbench": "letters"
        },
        {
          "id": "c08",
          "number": 8,
          "level": "intermediate",
          "points": 3,
          "topic": "5×5 checkerboard",
          "kind": "cipher",
          "prompt": "Decrypt the following checkerboard message. Enter the entire plaintext sentence. Punctuation and spaces will not affect grading.",
          "explanation": "The original message is “PACK FIVE BOXES WITH QUICK JUMPS AND ZERO WASTE.” Construct the 5×5 keyed Polybius square; each pair identifies one row and one column using the separate row and column keys. I/J use the same square cell.",
          "answer": "PACK FIVE BOXES WITH QUICK JUMPS AND ZERO WASTE",
          "ciphertext": "AW RW GO EO / RD GR TW GD / RO ES TR GD GW / TO GR AD EW / AO AS GR GO EO / GR AS ED AW GW / RW GS RR / TS GD AR ES / TO RW GW AD GD",
          "resource": "Polybius key: SCIENCE. Row-key letters: GREAT. Column-key letters: WORDS. Build the 5×5 grid by writing the unique letters of the Polybius key first (I/J share one cell), then the unused alphabet letters; fill rows left→right. Each ciphertext pair is (row-key letter, column-key letter).",
          "workbench": "pairs"
        },
        {
          "id": "c09",
          "number": 9,
          "level": "intermediate",
          "points": 3,
          "topic": "Homophonic ciphers",
          "kind": "cipher",
          "prompt": "Decrypt the following homophonic message. Enter the entire plaintext sentence. Punctuation and spaces will not affect grading.",
          "explanation": "The four-letter keyword is BAND; the recovered plaintext is “LOOK FOR PATTERNS BEFORE YOU GUESS THE MESSAGE.” Each number belongs to one of four 25-number bands. Start each band at its keyword letter and advance through the 25-letter I/J-combined alphabet, wrapping around. Subtract the band start to obtain the alphabet offset; keep the same offset from the band's keyword letter.",
          "answer": "LOOK FOR PATTERNS BEFORE YOU GUESS THE MESSAGE",
          "ciphertext": "10 52 13 35 / 31 39 42 / 40 98 18 44 68 89 12 43 / 01 04 05 52 16 68 / 23 39 45 / 32 19 04 90 90 / 91 33 77 / 84 30 56 90 26 70 04",
          "resource": "Four-band homophonic cipher; known keyword letters (in order): BAN?. Each 25-number band (01–25, 26–50, 51–75, 76–00) maps its FIRST number to the corresponding keyword letter, then continues alphabetically through ABCDEFGHIKLMNOPQRSTUVWXYZ, wrapping around. The token 00 denotes 100. Each plaintext letter can use any of its four band numbers. Spaces/slashes separate words.",
          "workbench": "tokens"
        },
        {
          "id": "c10",
          "number": 10,
          "level": "intermediate",
          "points": 3,
          "topic": "Aristocrat substitutions",
          "kind": "cipher",
          "prompt": "Decrypt the following aristocrat message. Enter the entire plaintext sentence. Punctuation and spaces will not affect grading.",
          "explanation": "The decoded message is “THE MOST USEFUL CLUE MAY BE A REPEATED THREE LETTER WORD.” Substitution is one-to-one throughout the question, so repeated cipher letters always stand for repeated plaintext letters. Use word lengths, frequency, and confirmed mappings to complete the alphabet.",
          "answer": "THE MOST USEFUL CLUE MAY BE A REPEATED THREE LETTER WORD",
          "ciphertext": "RQG BLCR ICGDIU FUIG BOT JG O YGKGORGV RQYGG UGRRGY NLYV",
          "resource": "Known plaintext→ciphertext pairs: E→G, T→R, A→O, H→Q. Other mappings must be inferred from word patterns.",
          "workbench": "letters"
        },
        {
          "id": "c11",
          "number": 11,
          "level": "advanced",
          "points": 5,
          "topic": "5×5 checkerboard",
          "kind": "cipher",
          "prompt": "Decrypt the following checkerboard message. Enter the entire plaintext sentence. Punctuation and spaces will not affect grading.",
          "explanation": "The original message is “BRAVE WIZARDS QUICKLY MIX JUGS OF FROZEN PAINT.” Construct the 5×5 keyed Polybius square; each pair identifies one row and one column using the separate row and column keys. I/J use the same square cell.",
          "answer": "BRAVE WIZARDS QUICKLY MIX JUGS OF FROZEN PAINT",
          "ciphertext": "RR GD RW TW GR / TO ER TS RW GD RS AD / AR AS ER RD ED RO TD / GS ER TR / ER AS EO AD / AW EW / EW GD AW TS GR ES / AO RW ER ES GW",
          "resource": "Polybius key: THERMAL. Row-key letters: GREAT. Column-key letters: WORDS. Build the 5×5 grid by writing the unique letters of the Polybius key first (I/J share one cell), then the unused alphabet letters; fill rows left→right. Each ciphertext pair is (row-key letter, column-key letter).",
          "workbench": "pairs"
        },
        {
          "id": "c12",
          "number": 12,
          "level": "advanced",
          "points": 5,
          "topic": "Homophonic ciphers",
          "kind": "cipher",
          "prompt": "Decrypt the following homophonic message. Enter the entire plaintext sentence. Punctuation and spaces will not affect grading.",
          "explanation": "The four-letter keyword is RISK; the recovered plaintext is “FREQUENCY COUNTS CAN MISLEAD WHEN LETTERS HAVE MANY SYMBOLS.” Each number belongs to one of four 25-number bands. Start each band at its keyword letter and advance through the 25-letter I/J-combined alphabet, wrapping around. Subtract the band start to obtain the alphabet offset; keep the same offset from the band's keyword letter.",
          "answer": "FREQUENCY COUNTS CAN MISLEAD WHEN LETTERS HAVE MANY SYMBOLS",
          "ciphertext": "48 83 14 33 53 47 30 94 90 / 12 72 53 30 03 51 / 61 43 30 / 70 18 51 69 63 43 13 / 39 99 47 30 / 20 14 85 36 63 34 84 / 66 43 38 14 / 29 10 30 41 / 84 41 29 44 31 77 02",
          "resource": "Four-band homophonic cipher; known keyword letters (in order): RIS?. Each 25-number band (01–25, 26–50, 51–75, 76–00) maps its FIRST number to the corresponding keyword letter, then continues alphabetically through ABCDEFGHIKLMNOPQRSTUVWXYZ, wrapping around. The token 00 denotes 100. Each plaintext letter can use any of its four band numbers. Spaces/slashes separate words.",
          "workbench": "tokens"
        },
        {
          "id": "c13",
          "number": 13,
          "level": "advanced",
          "points": 5,
          "topic": "Aristocrat substitutions",
          "kind": "cipher",
          "prompt": "Decrypt the following aristocrat message. Enter the entire plaintext sentence. Punctuation and spaces will not affect grading.",
          "explanation": "The decoded message is “WHEN EVERY SYMBOL SEEMS RANDOM SEARCH FOR WORD BOUNDARIES AND REPEATED ENDINGS BEFORE MAKING A GUESS.” Substitution is one-to-one throughout the question, so repeated cipher letters always stand for repeated plaintext letters. Use word lengths, frequency, and confirmed mappings to complete the alphabet.",
          "answer": "WHEN EVERY SYMBOL SEEMS RANDOM SEARCH FOR WORD BOUNDARIES AND REPEATED ENDINGS BEFORE MAKING A GUESS",
          "ciphertext": "HRBV BWBFG OGCMJI OBBCO FYVLJC OBYFXR DJF HJFL MJKVLYFEBO YVL FBSBYQBL BVLEVZO MBDJFB CYAEVZ Y ZKBOO",
          "resource": "No substitution alphabet is supplied. Spaces are preserved; no plaintext letter encrypts to itself.",
          "workbench": "letters"
        },
        {
          "id": "c14",
          "number": 14,
          "level": "advanced",
          "points": 5,
          "topic": "5×5 checkerboard",
          "kind": "cipher",
          "prompt": "Decrypt the following checkerboard message. Enter the entire plaintext sentence. Punctuation and spaces will not affect grading.",
          "explanation": "The original message is “FIVE QUICK BOXERS JUMP WHILE ZANY WIZARDS STUDY CIPHER GRIDS.” Construct the 5×5 keyed Polybius square; each pair identifies one row and one column using the separate row and column keys. I/J use the same square cell.",
          "answer": "FIVE QUICK BOXERS JUMP WHILE ZANY WIZARDS STUDY CIPHER GRIDS",
          "ciphertext": "EO RW TO EW / AO TW RW RS ES / RD GW TD EW AR AD / RW TW GD GS / TR ED RW GO EW / TS RO AW GR / TR RW TS RO AR RR AD / AD AS TW RR GR / RS RW GS ED EW AR / ER AR RW RR AD",
          "resource": "Polybius key: OLYMPIAD. Row-key letters: GREAT. Column-key letters: WORDS. Build the 5×5 grid by writing the unique letters of the Polybius key first (I/J share one cell), then the unused alphabet letters; fill rows left→right. Each ciphertext pair is (row-key letter, column-key letter).",
          "workbench": "pairs"
        },
        {
          "id": "c15",
          "number": 15,
          "level": "advanced",
          "points": 5,
          "topic": "Homophonic ciphers",
          "kind": "cipher",
          "prompt": "Decrypt the following homophonic message. Enter the entire plaintext sentence. Punctuation and spaces will not affect grading.",
          "explanation": "The four-letter keyword is GLOW; the recovered plaintext is “THE FINAL MESSAGE REVEALS THAT PATIENCE AND CAREFUL RECORD KEEPING WIN THE CIPHER RACE.” Each number belongs to one of four 25-number bands. Start each band at its keyword letter and advance through the 25-letter I/J-combined alphabet, wrapping around. Subtract the band start to obtain the alphabet offset; keep the same offset from the band's keyword letter.",
          "answer": "THE FINAL MESSAGE REVEALS THAT PATIENCE AND CAREFUL RECORD KEEPING WIN THE CIPHER RACE",
          "ciphertext": "98 87 67 / 25 71 07 20 26 / 74 45 55 12 20 01 45 / 32 24 58 84 20 90 55 / 13 87 80 13 / 52 41 13 03 45 28 22 45 / 20 75 44 / 43 20 54 24 68 57 90 / 54 24 82 93 96 83 / 89 24 45 52 03 07 86 / 37 49 28 / 13 48 67 / 43 71 52 02 84 54 / 11 41 22 67",
          "resource": "Four-band homophonic cipher; known keyword letters (in order): GLO?. Each 25-number band (01–25, 26–50, 51–75, 76–00) maps its FIRST number to the corresponding keyword letter, then continues alphabetically through ABCDEFGHIKLMNOPQRSTUVWXYZ, wrapping around. The token 00 denotes 100. Each plaintext letter can use any of its four band numbers. Spaces/slashes separate words.",
          "workbench": "tokens"
        }
      ]
    }
  }
};
