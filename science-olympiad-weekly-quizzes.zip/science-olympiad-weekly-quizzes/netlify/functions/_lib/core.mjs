import { BANK } from './bank.mjs';

export function json(value, status=200) {
  return new Response(JSON.stringify(value), {status, headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
}
export function getQuiz(id){return BANK.quizzes[id] || null;}
export function normalizeSequence(x){return String(x??'').toUpperCase().replace(/[^ACGTU]/g,'');}
export function normalizeLetters(x){return String(x??'').toUpperCase().replace(/[^A-Z]/g,'').replace(/J/g,'I');}
export function normalizeText(x){return String(x??'').trim().toUpperCase().replace(/\s+/g,' ');}
export function publicQuiz(quiz){
  return {
    version:BANK.version,
    title:quiz.title,subtitle:quiz.subtitle,color:quiz.color,materials:quiz.materials,topics:quiz.topics,
    questions:quiz.questions.map(q=>{
      const {id,number,level,points,topic,kind,prompt,options,label,unit,fields,ciphertext,resource,workbench}=q;
      const o={id,number,level,points,topic,kind,prompt};
      if(options)o.options=options;
      if(label)o.label=label;
      if(unit)o.unit=unit;
      if(fields)o.fields=fields.map(({label,mode})=>({label,mode}));
      if(ciphertext)o.ciphertext=ciphertext;
      if(resource)o.resource=resource;
      if(workbench)o.workbench=workbench;
      return o;
    })
  };
}
const clamp=(x,lo,hi)=>Math.max(lo,Math.min(hi,x));
const round=n=>Math.round(n*1000)/1000;
function scoreAtomic(answer,truth,mode,tolerance=0){
  if(mode==='number'){
    const s=String(answer??'').trim();
    if(!/^[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[-+]?\d+)?$/i.test(s))return 0;
    return Math.abs(Number(s)-Number(truth))<=tolerance+1e-9?1:0;
  }
  if(mode==='sequence'){
    const v=normalizeSequence(answer);const ref=normalizeSequence(truth);
    if(!ref)return 0;
    let matches=0;for(let i=0;i<Math.min(v.length,ref.length);i++)if(v[i]===ref[i])matches++;
    return matches/Math.max(ref.length,v.length);
  }
  return normalizeText(answer)===normalizeText(truth)?1:0;
}
export function scoreQuestion(q, answer){
 let fraction=0;
 const correct=q.kind==='choice' ? q.options[q.correct] : q.kind==='multi' ? q.correct.map(i=>q.options[i]) : q.kind==='fields' ? q.fields.map(f=>`${f.label}: ${f.answer}`) : q.answer;
 switch(q.kind){
  case 'choice': fraction=String(answer??'')===String(q.correct)?1:0; break;
  case 'multi': {
   const vals=Array.isArray(answer)?answer:[];
   const picked=new Set(vals.map(String).filter(v=>/^[0-3]$/.test(v)));
   const good=q.correct.filter(c=>picked.has(String(c))).length;
   const bad=[...picked].filter(v=>!q.correct.includes(Number(v))).length;
   fraction=clamp((good-bad)/q.correct.length,0,1);break;
  }
  case 'number': fraction=scoreAtomic(answer,q.answer,'number',q.tolerance);break;
  case 'sequence': fraction=scoreAtomic(answer,q.answer,'sequence');break;
  case 'fields': {
    let vals=Array.isArray(answer)?answer:[];
    fraction=q.fields.reduce((sum,f,i)=>sum+scoreAtomic(vals[i],f.answer,f.mode,f.tolerance||0),0)/q.fields.length;
    break;
  }
  case 'cipher': {
    const a=String(answer??'').toUpperCase().replace(/J/g,'I').replace(/[^A-Z_]/g,''); const b=normalizeLetters(q.answer);
    let match=0;for(let i=0;i<Math.min(a.length,b.length);i++)if(a[i]===b[i])match++;
    fraction=match/Math.max(a.length,b.length);break;
  }
 }
 return {id:q.id,number:q.number,topic:q.topic,level:q.level,kind:q.kind,points:q.points,earned:round(q.points*fraction),fraction:round(fraction),question:q.prompt,studentAnswer:q.kind==='choice' ? (q.options[Number(answer)]||'No answer') : q.kind==='multi' ? (Array.isArray(answer)?answer.map(i=>q.options[Number(i)]).filter(Boolean):[]) : answer??'',correctAnswer:correct,explanation:q.explanation};
}
export function grade(quiz,answers){
 const list=quiz.questions.map(q=>scoreQuestion(q,answers[q.id]));
 return {earned_points:round(list.reduce((s,x)=>s+x.earned,0)),max_points:quiz.questions.reduce((s,x)=>s+x.points,0),results:list};
}
export function demo(){return process.env.LOCAL_DEMO==='1' && process.env.NETLIFY!=='true';}
export const demoAttempts=[];
export async function requireJson(request,max=30000){
 const raw=await request.text(); if(raw.length>max)throw new Error('Payload too large');
 try{return JSON.parse(raw);}catch{throw new Error('Invalid JSON');}
}
export async function sbRequest(path,{method='GET',body,auth='service',bearer}={}){
 const url=process.env.SUPABASE_URL?.replace(/\/$/,'');
 const apiKey=auth==='anon'?process.env.SUPABASE_ANON_KEY:process.env.SUPABASE_SERVICE_ROLE_KEY;
 if(!url||!apiKey)throw new Error('Supabase server environment variables are not configured');
 const headers={apikey:apiKey, 'Content-Type':'application/json'};
 headers.Authorization=`Bearer ${bearer || apiKey}`;
 if(auth==='service')headers.Prefer='return=representation';
 const res=await fetch(url+path,{method,headers,body:body?JSON.stringify(body):undefined});
 const data=await res.json().catch(()=>({}));
 if(!res.ok){throw Object.assign(new Error(data.msg||data.message||data.error_description||data.error||'Database request failed'),{status:res.status});}
 return data;
}
export async function checkAdmin(request){
 const token=(request.headers.get('authorization')||'').match(/^Bearer ([\w.-]+)$/)?.[1];
 if(!token)throw Object.assign(new Error('Admin login required'),{status:401});
 if(demo()){
  if(token==='demo-local-token')return {id:'demo'};
  throw Object.assign(new Error('Invalid demo session'),{status:401});
 }
 const user=await sbRequest('/auth/v1/user',{auth:'anon',bearer:token});
 if(!process.env.ADMIN_USER_ID||user.id!==process.env.ADMIN_USER_ID){throw Object.assign(new Error('This account does not have dashboard access'),{status:403});}
 return user;
}
export function errorResponse(error){
 console.error('[Quiz API]',error?.message||error);
 return json({error:error?.message||'Unexpected server error'},Number.isInteger(error?.status)&&error.status>=400&&error.status<=599?error.status:500);
}
