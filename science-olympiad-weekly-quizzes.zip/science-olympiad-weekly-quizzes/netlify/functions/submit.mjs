import {json,getQuiz,grade,requireJson,sbRequest,demo,demoAttempts,errorResponse} from './_lib/core.mjs';
export default async function(request){
  if(request.method!=='POST')return json({error:'Method not allowed'},405);
  try{
    const data=await requireJson(request,30000);
    const name=String(data.studentName??'').trim().replace(/\s+/g,' ');
    if(name.length<2||name.length>80||/[<>\u0000-\u001f]/.test(name))return json({error:'Enter a name between 2 and 80 characters'},400);
    const quiz=getQuiz(data.quizId);
    if(!quiz)return json({error:'Unknown quiz'},400);
    if(data.version!== '2026-week1-v1')return json({error:'Quiz version changed. Please refresh and try again.'},409);
    const answers=data.answers;
    if(!answers||Array.isArray(answers)||typeof answers!=='object')return json({error:'Answers must be an object'},400);
    const valid=new Set(quiz.questions.map(q=>q.id));
    if(Object.keys(answers).some(k=>!valid.has(k)))return json({error:'Unknown question in submission'},400);
    if(Object.values(answers).some(v=>JSON.stringify(v).length>5000))return json({error:'Answer is too long'},400);
    const result=grade(quiz,answers);
    const record={student_name:name,quiz_id:data.quizId,earned_points:result.earned_points,max_points:result.max_points,question_results:result.results,submitted_answers:answers};
    let attemptId;
    if(demo()){
      attemptId='demo-'+(demoAttempts.length+1);
      demoAttempts.push({...record,id:attemptId,created_at:new Date().toISOString()});
    }else{
      const created=await sbRequest('/rest/v1/quiz_attempts',{method:'POST',body:record});
      attemptId=created[0]?.id;
      if(!attemptId)throw new Error('No submission receipt returned from database');
    }
    return json({attemptId,studentName:name,quizId:data.quizId,...result});
  }catch(e){return errorResponse(e);}
}
