import {json,checkAdmin,demo,demoAttempts,sbRequest,errorResponse} from './_lib/core.mjs';
export default async function(request){
  if(request.method!=='GET')return json({error:'Method not allowed'},405);
  try{
    await checkAdmin(request);
    const url=new URL(request.url);
    const offset=Math.min(100000,Math.max(0,Number(url.searchParams.get('offset'))||0));
    const limit=200;
    const attempts=demo()?demoAttempts.slice().reverse().slice(offset,offset+limit+1):await sbRequest(`/rest/v1/quiz_attempts?select=*&order=created_at.desc&limit=${limit+1}&offset=${offset}`);
    return json({attempts:attempts.slice(0,limit),hasMore:attempts.length>limit,nextOffset:offset+limit});
  }catch(e){return errorResponse(e);}
}
