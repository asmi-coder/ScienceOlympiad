import {json,getQuiz,publicQuiz} from './_lib/core.mjs';
export default async function(request){
  if(request.method!=='GET')return json({error:'Method not allowed'},405);
  const id=new URL(request.url).searchParams.get('id');
  const quiz=getQuiz(id);
  if(!quiz)return json({error:'Unknown quiz'},404);
  return json(publicQuiz(quiz));
}
